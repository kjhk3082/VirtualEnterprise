<?php
	include_once "../include/pageJustice.inc.php";
	
	$tpl = new skinController();
	
	/*
	템플릿 로드
	*/
	$tpl->skin_file_path("admin/_tpl/header.inc.html");

	/*
	템플릿 함수
	*/
	//모듈 메뉴 인클루드
	function modules_menuInclude(){
		global $m;
		$path = opendir(__DIR_PATH__."modules/");
		while($dir = readdir($path)){
			if($dir!="."&&$dir!=".."){
				$modules_headerTpl[$dir] = new skinController();
				$modules_headerTpl[$dir]->skin_file_path("modules/{$dir}/configure/header.inc.html");
				if($m==$dir){
					$activeName = "02";
				}else{
					$activeName = "01";
				}
				//메뉴 이미지 치환
				$modules_headerTpl[$dir]->skin_modeling("[header_nav_active]",__URL_PATH__."modules/{$dir}/configure/lay_mmenu01".$activeName.".jpg");
			}
		}
		if(count($modules_headerTpl)>0){
			foreach($modules_headerTpl as $val){
				$modules_headerTpl_outputs .= $val->skin_echo();
			}
			return $modules_headerTpl_outputs;
		}
	}
	//메뉴 Active 이미지 파일명 리턴
	function header_nav_active($num){
		global $p,$m;
		//기본 페이지명 배열 선언
		$n01 = array(
			"adminInfo","siteDefaultInfo","memberLevel","emptyTempFiles","mailTplAccount","mailTplMailling","mailTplPassword","menuSetting","menuSetting_modify"
		);
		$n02 = array(
			"memberList","memberList_modify","leaveMember","connectingMember","countResult"
		);
		$n03 = array(
			"bodyStyle","mainVisual","footerDesign","pageList","pageList_modify"
		);
		$n04 = array(
			"questionList","questionList_view","mailling","maillingList","maillingList_view"
		);
		$n05 = array(
			"popupList","popupList_modify"
		);
		$n06 = array(
			"blockMember","addBlockMember","blockIP","addBlockIP"
		);
		//메뉴 이미지 출력
		foreach($$num as $val){
			if(($val==$p)&&!$m) $sameCount++;
		}
		if($sameCount>0){
			$activeName = "02";
		}else{
			$activeName = "01";
		}
		return "images/lay_mmenu".substr($num,1).$activeName.".jpg";
	}
	
	/*
	템플릿 치환
	*/
	$tpl->skin_modeling("[header_nav_active_01]",header_nav_active("n01"));
	$tpl->skin_modeling("[header_nav_active_02]",header_nav_active("n02"));
	$tpl->skin_modeling("[header_nav_active_03]",header_nav_active("n03"));
	$tpl->skin_modeling("[header_nav_active_04]",header_nav_active("n04"));
	$tpl->skin_modeling("[header_nav_active_05]",header_nav_active("n05"));
	$tpl->skin_modeling("[header_nav_active_06]",header_nav_active("n06"));
	$tpl->skin_modeling("[modules_menuInclude]",modules_menuInclude());
	$tpl->skin_modeling("[gotoHomepageUrl]",$site_config['ad_site_url']);
	
	echo $tpl->skin_echo();
?>
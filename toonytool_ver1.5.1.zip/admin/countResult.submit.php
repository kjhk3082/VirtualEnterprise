<?php
	include "../include/engine.inc.php";
	include __DIR_PATH__."include/global.php";
	
	$lib = new libraryClass();
	$method = new methodController();
	$mysql = new mysqlConnection();
	
	$method->method_param("POST","reset_true");
	$lib->security_filter("referer");
	$lib->security_filter("request_get");
	
	/*
	검사
	*/
	if($reset_true!="ok"){
		echo '<!--error::not_variables-->'; exit;
	}
	$mysql->select("
		SELECT *
		FROM toony_admin_counter
	");
	if($mysql->numRows()<1){
		echo '<!--error::not_data-->'; exit;
	}
	
	/*
	모든 데이터 지움
	*/
	$mysql->query("
		DELETE 
		FROM toony_admin_counter
	");
	
	/*
	비밀번호 인풋에 값이 입력된 경우 비밀번호를 변경함
	*/
	if(trim($password)!=""){
		if($password!=$password02){
			echo '<!--error::not_samePassword-->'; exit;
		}
		$lib->func_method_param_check("password",$password,"<!--error::not_password-->");
		$password_val = "password('$password')";
	}else{
		$password_val = "'{$array['me_password']}'";
	}
	
	/*
	완료 후 리턴
	*/
	echo '<!--success::1-->';
	
	
?>
<?php
	$tpl = new skinController();
	
	/*
	템플릿 함수
	*/
	//모듈 사이드바 인클루드
	function modules_sideBarInclude(){
		global $m,$p;
		$path = opendir(__DIR_PATH__."modules/");
		while($dir = readdir($path)){
			if(($dir!="."&&$dir!="..")&&($p==""||$m==$dir)){
				$modules_sidebarTpl['$dir'] = new skinController();
				$modules_sidebarTpl['$dir']->skin_file_path("modules/{$dir}/configure/sidebar.inc.html");
			}
		}
		if(count($modules_sidebarTpl)>0){
			foreach($modules_sidebarTpl as $val){
				$modules_sidebarTpl_outputs .= $val->skin_echo();
			}
			return $modules_sidebarTpl_outputs;
		}
	}
	//페이지에 따른 사이드바 출력
	function sidebarShowFunc($num){
		global $p,$m;
		//기본 페이지명 배열 선언
		$n01 = array(
			"adminInfo","siteDefaultInfo","memberLevel","emptyTempFiles","mailTplAccount","mailTplMailling","mailTplPassword","menuSetting","menuSetting_modify"
		);
		$n02 = array(
			"memberList","memberList_modify","leaveMember","connectingMember","countResult","graph"
		);
		$n03 = array(
			"bodyStyle","mainVisual","footerDesign","pageList","pageList_modify"
		);
		$n04 = array(
			"questionList","questionList_view","mailling","maillingList","maillingList_view"
		);
		$n05 = array(
			"popupList","popupList_modify"
		);
		$n06 = array(
			"blockMember","addBlockMember","blockIP","addBlockIP"
		);
		//메뉴 이미지 출력
		foreach($$num as $val){
			if(($val==$p||$p=="")&&!$m) $sameCount++;
		}
		if($sameCount>0){
			$displayVal = "show";
		}else{
			$displayVal = "hide";
		}
		return $displayVal;
	}
	
	/*
	템플릿 로드
	*/
	$tpl->skin_file_path("admin/_tpl/sidebar.inc.html");
	
	/*
	템플릿 치환
	*/
	if($member['me_admin']=="Y"){
		$tpl->skin_modeling_hideArea("[{adminInfo_menuDisplay_start}]","[{adminInfo_menuDisplay_end}]","show");
	}else{
		$tpl->skin_modeling_hideArea("[{adminInfo_menuDisplay_start}]","[{adminInfo_menuDisplay_end}]","hide");
	}
	$tpl->skin_modeling("[modules_sideBarInclude]",modules_sideBarInclude());
	$tpl->skin_modeling_hideArea("[{sidebar_01_start}]","[{sidebar_01_end}]",sidebarShowFunc("n01"));
	$tpl->skin_modeling_hideArea("[{sidebar_02_start}]","[{sidebar_02_end}]",sidebarShowFunc("n02"));
	$tpl->skin_modeling_hideArea("[{sidebar_03_start}]","[{sidebar_03_end}]",sidebarShowFunc("n03"));
	$tpl->skin_modeling_hideArea("[{sidebar_04_start}]","[{sidebar_04_end}]",sidebarShowFunc("n04"));
	$tpl->skin_modeling_hideArea("[{sidebar_05_start}]","[{sidebar_05_end}]",sidebarShowFunc("n05"));
	$tpl->skin_modeling_hideArea("[{sidebar_06_start}]","[{sidebar_06_end}]",sidebarShowFunc("n06"));
	
	echo $tpl->skin_echo();
?>
<?php
	//header
	$header->skin_modeling("[board_id_value]",$board_id);
	$header->skin_modeling("[page_value]",$page);
	$header->skin_modeling("[article_value]",$article);
	$header->skin_modeling("[category_value]",$category);
	$header->skin_modeling("[bbs_setting]",bbs_setting_btn());
	$header->skin_modeling("[bbs_category]",bbs_category());
	$header->skin_modeling("[board_title]",$c_array[name]);
	if($member['me_level']<=$c_array['controll_level']||$member['me_admin']=="Y"){
		$header->skin_modeling_hideArea("[{controll_chk_start}]","[{controll_chk_end}]","show");
	}else{
		$header->skin_modeling_hideArea("[{controll_chk_start}]","[{controll_chk_end}]","hide");
	}
	echo $header->skin_echo();
	//notice array
	$paging_query = "
		SELECT *,
		(
			SELECT COUNT(*)
			FROM toony_module_board_comment_$board_id
			WHERE bo_idno=A.idno
		) cmtnum,
		(
			SELECT COUNT(*)
			FROM toony_module_board_like
			WHERE board_id='$board_id' AND read_idno=A.idno AND likes>0
		) likes_count,
		(
			SELECT COUNT(*)
			FROM toony_module_board_like
			WHERE board_id='$board_id' AND read_idno=A.idno AND unlikes>0
		) unlikes_count
		FROM toony_module_board_data_$board_id A
		WHERE A.use_notice='Y'
		ORDER BY A.idno DESC
	";
	$mysql->select($paging_query);
	$array_total = $mysql->numRows();
	if($array_total>0){
		do{
			$mysql->fetchArray("category,writer,subject,name,me_nick,idno,me_idno,regdate,view,vote,cmtnum,use_secret,use_html,file1,file2,rn,likes_count,unlikes_count");
			$array = $mysql->array;
			$notice_loop->skin_modeling("[controll_chk]",array_subject_controll_chk());
			$notice_loop->skin_modeling("[subject]",bbs_subject_title());
			$notice_loop->skin_modeling("[hit]",number_format((int)$array['view']));
			$notice_loop->skin_modeling("[write_date]",date("y/m/d",strtotime($array['regdate'])));
			$notice_loop->skin_modeling("[write_datetime]",date("y.m.d H:i:s",strtotime($array['regdate'])));
			$notice_loop->skin_modeling("[writer]",bbs_me_nick());
			$notice_loop->skin_modeling("[comment_num]",array_subject_comment());
			$notice_loop->skin_modeling("[file_ico]",array_subject_file());
			$notice_loop->skin_modeling("[secret_ico]",array_subject_secret());
			$notice_loop->skin_modeling("[mobile_ico]",array_subject_mobile());
			$notice_loop->skin_modeling("[likes]",$array['likes_count']);
			$notice_loop->skin_modeling("[unlikes]",$array['unlikes_count']);
			$notice_loop->skin_modeling("[category_name]",array_category_name());
			if($member['me_level']<=$c_array['controll_level']||$member['me_admin']=="Y"){
				$notice_loop->skin_modeling_hideArea("[{controll_chk_start}]","[{controll_chk_end}]","show");
			}else{
				$notice_loop->skin_modeling_hideArea("[{controll_chk_start}]","[{controll_chk_end}]","hide");
			}
			if($c_array['use_likes']=="Y"){
				$notice_loop->skin_modeling_hideArea("[{likes_start}]","[{likes_end}]","show");
			}else{
				$notice_loop->skin_modeling_hideArea("[{likes_start}]","[{likes_end}]","hide");
			}
			echo $notice_loop->skin_echo();
		}while($mysql->nextRec());
	}
	//array
	$paging_query = "
		SELECT *,
		(
			SELECT COUNT(*)
			FROM toony_module_board_comment_$board_id 
			WHERE bo_idno=A.idno
		) cmtnum,
		(
			SELECT COUNT(*)
			FROM toony_module_board_like
			WHERE board_id='$board_id' AND read_idno=A.idno AND likes>0
		) likes_count,
		(
			SELECT COUNT(*)
			FROM toony_module_board_like
			WHERE board_id='$board_id' AND read_idno=A.idno AND unlikes>0
		) unlikes_count
		FROM toony_module_board_data_$board_id A
		WHERE A.use_notice='N' $search
		ORDER BY A.ln DESC, A.rn ASC, A.regdate DESC
	";
	$mysql->select($paging_query);
	$paging_query_no = $mysql->numRows();
	$paging->page_param($page);
	$total_num = $paging->setTotal($paging_query_no);
	$paging->setListPerPage($c_array['list_limit']);
	$sql = $paging->getPaggingQuery($paging_query);
	$mysql->select($sql);
	$array_total = $mysql->numRows();
	if($array_total>0){
		$j = 1;
		do{
			$mysql->fetchArray("category,writer,subject,ment,name,me_nick,idno,me_idno,regdate,view,vote,cmtnum,use_secret,use_html,file1,file2,rn,likes_count,unlikes_count");
			$array = $mysql->array;
			$array_loop->skin_modeling("[controll_chk]",array_subject_controll_chk());
			$array_loop->skin_modeling("[subject]",bbs_subject_title());
			$array_loop->skin_modeling("[ment]",bbs_ment_title());
			$array_loop->skin_modeling("[number]",bbs_number($paging->getNo($i)));$i++;
			$array_loop->skin_modeling("[hit]",number_format((int)$array['view']));
			$array_loop->skin_modeling("[write_date]",date("y.m.d",strtotime($array['regdate'])));
			$array_loop->skin_modeling("[write_datetime]",$array['regdate']);
			$array_loop->skin_modeling("[writer]",bbs_me_nick());
			$array_loop->skin_modeling("[thumbnail]",thumbnail_func());
			$array_loop->skin_modeling("[comment_num]",array_subject_comment());
			$array_loop->skin_modeling("[file_ico]",array_subject_file());
			$array_loop->skin_modeling("[secret_ico]",array_subject_secret());
			$array_loop->skin_modeling("[mobile_ico]",array_subject_mobile());
			$array_loop->skin_modeling("[likes]",$array['likes_count']);
			$array_loop->skin_modeling("[unlikes]",$array['unlikes_count']);
			$array_loop->skin_modeling("[category_name]",array_category_name());
			if($member['me_level']<=$c_array['controll_level']||$member['me_admin']=="Y"){
				$array_loop->skin_modeling_hideArea("[{controll_chk_start}]","[{controll_chk_end}]","show");
			}else{
				$array_loop->skin_modeling_hideArea("[{controll_chk_start}]","[{controll_chk_end}]","hide");
			}
			if($j==1){
				$array_loop->skin_modeling_hideArea("[{array_first_item_start}]","[{array_first_item_end}]","show");
				$array_loop->skin_modeling_hideArea("[{array_last_item_start}]","[{array_last_item_end}]","hide");
			}else if($j==$array_total){
				$array_loop->skin_modeling_hideArea("[{array_first_item_start}]","[{array_first_item_end}]","hide");
				$array_loop->skin_modeling_hideArea("[{array_last_item_start}]","[{array_last_item_end}]","show");
			}else{
				$array_loop->skin_modeling_hideArea("[{array_first_item_start}]","[{array_first_item_end}]","hide");
				$array_loop->skin_modeling_hideArea("[{array_last_item_start}]","[{array_last_item_end}]","hide");
			}
			if($c_array['use_likes']=="Y"){
				$array_loop->skin_modeling_hideArea("[{likes_start}]","[{likes_end}]","show");
			}else{
				$array_loop->skin_modeling_hideArea("[{likes_start}]","[{likes_end}]","hide");
			}
			echo $array_loop->skin_echo();
			$j++;
		}while($mysql->nextRec());
	}
	//footer
	if($array_total>0){
		$footer->skin_modeling_hideArea("[{array_not_loop_start}]","[{array_not_loop_end}]","hide");
	}else{
		$footer->skin_modeling_hideArea("[{array_not_loop_start}]","[{array_not_loop_end}]","show");
	}
	$footer->skin_modeling("[ss_selected]",$ss);
	$footer->skin_modeling("[sm_selected]",$sm);
	$footer->skin_modeling("[sw_selected]",$sw);
	$footer->skin_modeling("[keyword_value]",$keyword);
	$footer->skin_modeling("[write_btn]",bbs_write_btn());
	$footer->skin_modeling("[paging_area]",$paging->Show(__URL_PATH__."{$viewDir}?article={$article}&category={$category}&where={$where}&keyword={$keyword}"));
	$footer->skin_modeling("[controll_btn]",bbs_controll_btn());
	$footer->skin_modeling("[search_btn]","<input type=\"submit\" class=\"__button_small\" value=\"검색\" />");
	$footer->skin_modeling("[search_cancel_btn]","<input type=\"button\" class=\"__button_small_gray\" value=\"취소\" onclick=\"document.location.href='".__URL_PATH__."{$viewDir}?article={$article}';\"; />");
	echo $footer->skin_echo();
?>
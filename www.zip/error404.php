<html><head>
<meta charset="utf-8">
<style>html{height:100%}body{margin:0 auto;min-height:600px;min-width:800px;height:100%}.top{height:100px;height:calc(40% - 140px)}.bottom{height:150px;height:calc(60% - 210px)}.center{height:350px;text-align:center;vertical-align:middle;font-family:Verdana}.circle{margin:auto;width:260px;height:260px;border-radius:50%;background:#c0c6cc}.circle_text{line-height:260px;font-size:100px;color:#ffffff;font-weight:bold}.text{line-height:40px;font-size:26px;color:#505a64}
</style>
</head>
<body>
<div class="top"></div>
<div class="center">
<div class="circle">
<div class="circle_text">404</div>
</div>
<div>
<p class="text" id="a">찾고 계신 페이지를 발견할 수 없습니다.</p>
</div>
</div>
<div class="bottom"></div>


</body></html>

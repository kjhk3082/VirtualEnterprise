<?
include "../class/common.class.php";
if($sess['level']==9999){
    go('./dashboard.php');
}else{
    go('./login.php');
}

?>

<?
include "_common.php";

$mode = $_POST['mode'];

$image_ext = array('image/jpeg','image/png','image/gif');


#추가
if($mode=='add'){

    $img = '';

    if(!$_POST['code']){
        alert('코드를 작성해 주세요.');
        go('../blank.php');
    }


    if($_FILES['banner_file']['size']>0){

        if(!in_array($_FILES['banner_file']['type'],$image_ext)){
            alert('이미지 파일을 업로드 해주세요.');
            go('../blank.php');
        }else{
            $img = time().'_'.$_FILES['banner_file']['name'];
            @move_uploaded_file($_FILES['banner_file']['tmp_name'], '../skin/'.$cfg['skin'].'/img/'.$img);
        }

    }


    $query = "insert into w_banner set skin='".$cfg['skin']."', code='".$_POST['code']."', img='".$img."', alt='".$_POST['alt']."', href='".$_POST['href']."', target='".$_POST['target']."'";

    $db->query($query);

    alert('저장되었습니다.');

    parentGo('./banner.php');

}



#수정
if($mode=='mod'){

    $img = $_POST['img'];

    if($_POST['img_del']=='y'){
        unlink('../skin/'.$cfg['skin'].'/img/'.$img);
        $img = '';
    }

    if($_FILES['banner_file']['size']>0){

        if(!in_array($_FILES['banner_file']['type'],$image_ext)){
            alert('이미지 파일을 업로드 해주세요.');
            go('../blank.php');
        }else{
            $img = time().'_'.$_FILES['banner_file']['name'];
            @move_uploaded_file($_FILES['banner_file']['tmp_name'], '../skin/'.$cfg['skin'].'/img/'.$img);
        }

    }

    $query = "update w_banner set skin='".$cfg['skin']."', code='".$_POST['code']."', img='".$img."', alt='".$_POST['alt']."', href='".$_POST['href']."', target='".$_POST['target']."' where idx='".$_POST['idx']."'";

    $db->query($query);

    alert('저장되었습니다.');

    parentGo('./banner_add.php?idx='.$_POST['idx']);
}


#삭제
if($mode=='arr_del'){

    foreach($_POST['idx'] as $k=>$v){

        $query = "select img from w_banner where idx='".$v."'";
        list($img) = $db->fetch($query);

        if($img) @unlink('../skin/'.$cfg['skin'].'/img/'.$img);

        $query = "delete from w_banner where idx='".$v."'";
        $db->query($query);
    }

    parentGo('./banner.php');
}


?>

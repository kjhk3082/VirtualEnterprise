<?
include "_common.php";

$mode = $_POST['mode'];

if($mode=='add_skin'){


    // 핸들 획득
    $handle  = opendir('../skin');


    // 디렉터리에 포함된 파일을 저장한다.
    while (false !== ($filename = readdir($handle))) {
        if($filename == "." || $filename == ".."){
            continue;
        }

        // 파일인 경우만 목록에 추가한다.
        if(is_dir('../skin/'.$filename)){
            if($filename==$cfg['skin']) $checked['skin'][$filename]="checked";
            $dir[] = $filename;
        }
    }

    // 핸들 해제
    closedir($handle);



    if($_FILES['skin_file']['size']==0){
        alert('업로드할 파일을 선택해 주세요.');
        exit;
    }

    if(substr($_FILES['skin_file']['name'],-3)!="zip"){
        alert('ZIP 파일을 업로드 하세요.');
        exit;
    }


    $name = explode('.zip',$_FILES['skin_file']['name']);
    $dir_name = $name[0];


    foreach($dir as $k=>$v){
        if($v==$dir_name){
            alert('중복되는 스킨명 입니다. zip 파일의 파일명을 수정해주세요.');
            exit;
        }
    }


    @move_uploaded_file($_FILES['skin_file']['tmp_name'], './tmp/'.$_FILES['skin_file']['name']);


    $zip = new ZipArchive;

    $res = $zip->open('./tmp/'.$_FILES['skin_file']['name']);

    if ($res) {
        // 다음 디렉토리 위치에 압축파일을 해제
        $zip->extractTo('../skin');

        $zip->close();
    }


}

if($mode=='skin_change'){
    $query = "update w_config set data='".$_POST['skin']."' where code='skin'";
    $db->query($query);
}

alert('저장되었습니다.');


parentGo('./skin.php');

?>

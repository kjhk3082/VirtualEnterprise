<?
include "_common.php";

$file = '../skin/'.$cfg['skin'].'/css/style.css';

if (!is_writable($file)) {
    alert('파일 권한 문제로 수정할 수 없습니다. 개발자에게 문의 바랍니다.');
    go('../blank.php');
 }

$fp = fopen($file, "w");
$data = str_replace(array("\r\n","\r"),"\n",$_POST["data"]);
fwrite($fp, $data);
fclose($fp);

alert('저장되었습니다.');

parentGo('./css.php');

?>

<? include "./_header.php";
?>
<div id="solution">
    <nav><i class="fa fa-code-fork" aria-hidden="true"></i> 관리자 > 기타 > 솔루션소개</nav>

    <div class="form">
        <h2><i class="fa fa-cube" aria-hidden="true"></i> 솔루션</h2>

        <div class="desc">버전 2.6
개발회사 : 워크식스 (cs@work6.kr, 070-7557-8612)
개발자 : 김재원 (okhi1@naver.com)
        </div>
    </div>

    <div class="form">
        <h2><i class="fa fa-cube" aria-hidden="true"></i> 라이선스</h2>

        <div class="desc">워크식스 솔루션은 재판매 및 2차 가공 후 재판매를 제외한 사용, 복제, 배포, 수정을 누구나 할 수 있습니다.
위 내용을 위반한 경우 워크식스(또는 솔루션 개발자)는 법적 책임을 물을 수 있습니다.
        </div>
    </div>


    <div class="form">
        <h2><i class="fa fa-cube" aria-hidden="true"></i> 설치환경</h2>

        <div class="desc">Apache 2 이상
Charset UTF-8
PHP 5.6.00 이상
MYSQL 5.0 이상
        </div>
    </div>




</div>

<? include "./_footer.php"; ?>

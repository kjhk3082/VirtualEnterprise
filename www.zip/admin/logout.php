<?
include "../class/common.class.php";

session_destroy();

if($_GET['return'])go($_GET['return']);
go('/');

?>

<? include "./_header.php";

#style.css 파일 읽어오기
if(file_exists('../skin/'.$cfg['skin'].'/css/style.css')){
    $fp = fopen('../skin/'.$cfg['skin'].'/css/style.css', "r");
    while(!feof($fp)){
       $buffer .= fgets($fp);
    }
    fclose($fp);
}

?>

<link rel="stylesheet" href="/admin/jsplugin/codemirror/codemirror.css">
<script src="/admin/jsplugin/codemirror/codemirror.js"></script>
<script src="/admin/jsplugin/codemirror/active_line.js"></script>
<script src="/admin/jsplugin/codemirror/css.js"></script>

<div id="html">
    <nav><i class="fa fa-code-fork" aria-hidden="true"></i> 관리자 > 디자인 > CSS 관리</nav>

    <form method="post" enctype="multipart/form-data" action="./indb_css.php" target="ifrmh">

        <div class="form">
            <h2><i class="fa fa-cube" aria-hidden="true"></i> style.css</h2>
            <table>
                <colgroup>
    				<col>
    			</colgroup>
                <tr>
                    <td>
                        <textarea name="data"><?=$buffer?></textarea>
                    </td>
    			</tr>
    		</table>
        </div>


        <div class="btn_area">
            <button type="submit">저장</button>
        </div>

    </form>

</div>

<script>
var editor = CodeMirror.fromTextArea($('[name="data"]')[0],{
    lineNumbers: true,
    lineWrapping: true,
    styleActiveLine: true
});
</script>

<? include "./_footer.php"; ?>

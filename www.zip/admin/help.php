<? include "./_header.php";
?>
<div id="help">
    <nav><i class="fa fa-code-fork" aria-hidden="true"></i> 관리자 > 기타 > 도움말</nav>

    <div class="form">
        <h2><i class="fa fa-cube" aria-hidden="true"></i> 템플릿사전</h2>
        <table>
            <colgroup>
                <col width=180>
                <col>
            </colgroup>
            <tr>
                <th>
                    {=_cfg['site_name']}
                </th>
                <td>
                    기본 설정에서 사이트명을 가져옵니다.
                </td>
            </tr>
            <tr>
                <th>
                    {=_cfg['site_keywords']}
                </th>
                <td>
                    기본 설정에서 키워드를 가져옵니다.
                </td>
            </tr>
            <tr>
                <th>
                    {=_cfg['site_description']}
                </th>
                <td>
                    기본 설정에서 사이트설명을 가져옵니다.
                </td>
            </tr>
            <tr>
                <th>
                    {=_cfg['site_description']}
                </th>
                <td>
                    기본 설정에서 사이트설명을 가져옵니다.
                </td>
            </tr>
            <tr>
                <th>
                    {=_cfg['company_name']}
                </th>
                <td>
                    기본 설정에서 기업명을 가져옵니다.
                </td>
            </tr>
            <tr>
                <th>
                    {=_cfg['company_ceo']}
                </th>
                <td>
                    기본 설정에서 대표를 가져옵니다.
                </td>
            </tr>
            <tr>
                <th>
                    {=_cfg['company_addr']}
                </th>
                <td>
                    기본 설정에서 주소를 가져옵니다.
                </td>
            </tr>
            <tr>
                <th>
                    {=_cfg['company_tel']}
                </th>
                <td>
                    기본 설정에서 연락처를 가져옵니다.
                </td>
            </tr>
            <tr>
                <th>
                    {=_cfg['site_email']}
                </th>
                <td>
                    기본 설정에서 이메일을 가져옵니다.
                </td>
            </tr>
            <tr>
                <th>
                    {=_cfg['company_number']}
                </th>
                <td>
                    기본 설정에서 사업자번호를 가져옵니다.
                </td>
            </tr>
            <tr>
                <th>
                    {=_cfg['google_webmaster_code']}
                </th>
                <td>
                    웹마스터도구 설정에서 구글 인증키를 가져옵니다.
                </td>
            </tr>
            <tr>
                <th>
                    {=_cfg['naver_webmaster_code']}
                </th>
                <td>
                    웹마스터도구 설정에서 네이버 인증키를 가져옵니다.
                </td>
            </tr>
            <tr>
                <th>
                    {=getBanner('코드')}
                </th>
                <td>
                    배너/이미지 관리에서 이미지 또는 배너를 가져옵니다.
                </td>
            </tr>
            <tr>
                <th>
                    {=getPopup()}
                </th>
                <td>
                    팝업관리에 팝업을 가져옵니다.
                </td>
            </tr>
        </table>


    </div>

</div>

<? include "./_footer.php"; ?>

<? include "./_header.php";

    $mode = 'add';
    $navi = '추가';

    if($_GET['idx']){

        $mode = 'mod';
        $navi = '상세';

        $query = "select * from w_banner where idx='".$_GET['idx']."'";
        $data = $db->fetch($query);

        $selected['target'][$data['target']] = 'selected';

    }

?>
<div id="banner_add">
    <nav><i class="fa fa-code-fork" aria-hidden="true"></i> 관리자 > 디자인 > 배너/이미지 관리 > <?=$navi?></nav>

    <form method="post" enctype="multipart/form-data" action="./indb_banner.php" target="ifrmh">
        <input type="hidden" name="mode" value="<?=$mode?>">
        <input type="hidden" name="idx" value="<?=$_GET['idx']?>">

        <div class="form">
            <table>
                <colgroup>
                    <col width="180px">
    				<col>
    			</colgroup>
                <tr>
    				<th>코드</th>
                    <td><input type="text" name="code" value="<?=$data['code']?>"></td>
    			</tr>
                <tr>
    				<th>이미지</th>
                    <td>
                        <? if($data['img']){?>
                            <input type="hidden" name="img" value="<?=$data['img']?>">
                            <img src="../skin/<?=$cfg['skin']?>/img/<?=$data['img']?>"><br>
                            <label><input type="checkbox" name="img_del" value='y'> 이미지를 삭제하려면 체크하세요.</label><br>
                        <? }?>
                        <input type="file" name="banner_file" >
                    </td>
    			</tr>
                <tr>
    				<th>링크</th>
                    <td>
                        <select name="target">
                            <option value="self">현재창</option>
                            <option value="_blank" <?=$selected['target']['_blank']?>>새창</option>
                        </select>
                        <input type="text" name="href" value="<?=$data['href']?>" size=50></td>
    			</tr>
                <tr>
                    <th>이미지설명</th>
                    <td><input type="text" name="alt" value="<?=$data['alt']?>"></td>
                </tr>
    		</table>
        </div>


        <div class="btn_area">
            <button type="submit">저장</button>
        </div>

    </form>

</div>


<? include "./_footer.php"; ?>

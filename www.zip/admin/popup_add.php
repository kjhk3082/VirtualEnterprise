<? include "./_header.php";

    $mode = 'add';
    $navi = '추가';

    if($_GET['idx']){

        $mode = 'mod';
        $navi = '상세';

        $query = "select * from w_popup where idx='".$_GET['idx']."'";
        $data = $db->fetch($query);


        $selected['target'][$data['target']] = 'selected';

    }

?>
<div id="popup_add">
    <nav><i class="fa fa-code-fork" aria-hidden="true"></i> 관리자 > 디자인 > 팝업 관리 > <?=$navi?></nav>

    <form method="post" enctype="multipart/form-data" action="./indb_popup.php" target="ifrmh">
        <input type="hidden" name="mode" value="<?=$mode?>">
        <input type="hidden" name="idx" value="<?=$_GET['idx']?>">

        <div class="form">
            <table>
                <colgroup>
                    <col width="180px">
    				<col>
    			</colgroup>
                <tr>
    				<th>팝업명</th>
                    <td><input type="text" name="name" value="<?=$data['name']?>"></td>
    			</tr>
                <tr>
    				<th>이미지</th>
                    <td>
                        <? if($data['img']){?>
                            <input type="hidden" name="img" value="<?=$data['img']?>">
                            <img src="../skin/<?=$cfg['skin']?>/img/<?=$data['img']?>"><br>
                            <label><input type="checkbox" name="img_del" value='y'> 이미지를 삭제하려면 체크하세요.</label><br>
                        <? }?>
                        <input type="file" name="popup_file" >
                    </td>
    			</tr>
                <tr>
    				<th>팝업위치(px)</th>
                    <td>X축 : <input type="text" name="start_x" value="<?=$data['start_x']?>" size=2> Y축 : <input type="text" name="start_y" value="<?=$data['start_y']?>" size=2></td>
    			</tr>
                <tr>
    				<th>링크</th>
                    <td>
                        <select name="target">
                            <option value="self">현재창</option>
                            <option value="_blank" <?=$selected['target']['_blank']?>>새창</option>
                        </select>
                        <input type="text" name="href" value="<?=$data['href']?>" size=50></td>
    			</tr>
                <tr>
    				<th>그만보기시간설정(day)</th>
                    <td><input type="text" name="offdt" value="<?=$data['offdt']?>" size=3 placeholder="day"></td>
    			</tr>
                <tr>
    				<th>자동종료일</th>
                    <td><input type="text" name="enddt" value="<?=$data['enddt']?>"></td>
    			</tr>
    		</table>
        </div>


        <div class="btn_area">
            <button type="submit">저장</button>
        </div>

    </form>

</div>

<script>
  $( function() {
    $( "[name='enddt']" ).datepicker({ dateFormat: 'yy-mm-dd 23:59:59' });
  } );
</script>

<? include "./_footer.php"; ?>

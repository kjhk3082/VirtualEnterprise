<? include "./_header.php";
?>
<div id="conf">
    <nav><i class="fa fa-code-fork" aria-hidden="true"></i> 관리자 > 기본 > 기본 설정</nav>

    <form method="post" enctype="multipart/form-data" action="./indb_conf.php" target="ifrmh">

        <div class="form">
            <h2><i class="fa fa-cube" aria-hidden="true"></i> 메타데이터</h2>
            <table>
                <colgroup>
                    <col width="180px">
    				<col>
    			</colgroup>
                <tr>
    				<th>사이트명</th>
                    <td><input type="text" name="site_name" value="<?=$cfg['site_name']?>"></td>
    			</tr>
                <tr>
    				<th>키워드</th>
                    <td><input type="text" name="site_keywords" value="<?=$cfg['site_keywords']?>" size=100></td>
    			</tr>
                <tr>
    				<th>사이트설명</th>
                    <td><input type="text" name="site_description" value="<?=$cfg['site_description']?>" size=100></td>
    			</tr>
    		</table>
        </div>


        <div class="form">
            <h2><i class="fa fa-cube" aria-hidden="true"></i> 기업정보</h2>
            <table>
                <colgroup>
                    <col width="180px">
    				<col>
    			</colgroup>
                <tr>
    				<th>기업명</th>
                    <td><input type="text" name="company_name" value="<?=$cfg['company_name']?>"></td>
    			</tr>
                <tr>
    				<th>대표</th>
                    <td><input type="text" name="company_ceo" value="<?=$cfg['company_ceo']?>"></td>
    			</tr>
                <tr>
    				<th>주소</th>
                    <td><input type="text" name="company_addr" value="<?=$cfg['company_addr']?>" size=100></td>
    			</tr>
                <tr>
    				<th>연락처</th>
                    <td><input type="text" name="company_tel" value="<?=$cfg['company_tel']?>"></td>
    			</tr>
                <tr>
    				<th>이메일</th>
                    <td><input type="text" name="site_email" value="<?=$cfg['site_email']?>"></td>
    			</tr>
                <tr>
    				<th>사업자번호</th>
                    <td><input type="text" name="company_number" value="<?=$cfg['company_number']?>"></td>
    			</tr>
    		</table>
        </div>


        <div class="btn_area">
            <button type="submit">저장</button>
        </div>

    </form>

</div>

<? include "./_footer.php"; ?>

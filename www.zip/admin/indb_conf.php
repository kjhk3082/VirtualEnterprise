<?
include "_common.php";

foreach($_POST as $k=>$v){
    $query = "update w_config set data='".$v."' where code='".$k."'";
    $db->query($query);
}

alert('저장되었습니다.');

parentGo('./conf.php');

?>

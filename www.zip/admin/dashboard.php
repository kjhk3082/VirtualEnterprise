<?
include "./_header.php";


if(!$_COOKIE['work6license']){
	$url = 'http://work6.kr/solution/license';
	$post['host'] = $_SERVER['HOST'];
	if(!$post['host']) $post['host'] = $_SERVER['HTTP_HOST'];
	if(!$post['host']) $post['host'] = $_SERVER['SERVER_NAME'];

	$ch = @curl_init();

	if($ch){

		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_POST, true);  // Tell cURL you want to post something
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post); // Define what you want to post
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return the output in string format
		$res = curl_exec ($ch); // Execute

		curl_close ($ch); // Close cURL handle

		setcookie('work6license',$post['host'],time()+(60*60*24));

	}
}



#ad 가져오기
$ch = cURL_init();
$url = "http://work6.kr/solution/ad";
cURL_setopt($ch, CURLOPT_URL, $url);
cURL_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$response = cURL_exec($ch);
cURL_close($ch);

$ad = json_decode($response,ture);



#스킨 가져오기
$ch = cURL_init();
$url = "http://work6.kr/solution/skin";
cURL_setopt($ch, CURLOPT_URL, $url);
cURL_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$response = cURL_exec($ch);
cURL_close($ch);

$skin = json_decode($response,ture);



#패치 가져오기
$ch = cURL_init();
$url = "http://work6.kr/solution/patch";
cURL_setopt($ch, CURLOPT_URL, $url);
cURL_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$response = cURL_exec($ch);
cURL_close($ch);

$patch = json_decode($response,ture);


?>

<div id="dashboard">


    <div class="ad container">
        <h2><i class="fa fa-star-o" aria-hidden="true"></i> AD</h2>
        <? foreach($ad as $v){?>
        <a href="<?=$v['link']?>" target="_blank"><img src="<?=$v['img']?>"></a>
        <?}?>
    </div>


    <div class="skin container">
        <h2><i class="fa fa-television" aria-hidden="true"></i> 신규스킨소식</h2>
        <div class="list">
            <table>
                <colgroup>
                    <col width=100></col>
                    <col></col>
                    <col width=60></col>
                </colgroup>
                <tr>
                    <th>업데이트일자</th>
                    <th>제목</th>
                    <th>다운</th>
                </tr>
                <?
                if($skin){
                    foreach($skin as $v){?>
                    <tr>
                        <td><?=$v['date']?></td>
                        <td><?=$v['desc']?></td>
                        <td><a href="<?=$v['link']?>" target="_blank"><i class="fa fa-download" aria-hidden="true"></i></a></td>
                    </tr>
                    <?}
                }else{
                ?>
                <tr>
                    <td colspan="3" style="text-align:center;">데이터가 없습니다.</td>
                </tr>
                <? } ?>
            </table>
        </div>
    </div>


    <div class="patch container">
        <h2><i class="fa fa-cubes" aria-hidden="true"></i> 신규패치소식</h2>
        <div class="list">
            <table>
                <colgroup>
                    <col width=100></col>
                    <col></col>
                    <col width=60></col>
                </colgroup>
                <tr>
                    <th>업데이트일자</th>
                    <th>제목</th>
                    <th>다운</th>
                </tr>
                <?
                if($patch){
                foreach($patch as $v){?>
                <tr>
                    <td><?=$v['date']?></td>
                    <td><?=$v['desc']?></td>
                    <td><a href="<?=$v['link']?>" target="_blank"><i class="fa fa-download" aria-hidden="true"></i></a></td>
                </tr>
                <?}
                }else{?>
                <tr>
                    <td colspan="3" style="text-align:center;">데이터가 없습니다.</td>
                </tr>
                <?}?>
            </table>
        </div>
    </div>

</div>


<? include "./_footer.php"; ?>

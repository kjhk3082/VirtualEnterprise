<? include "./_header.php";
?>
<div id="webmaster">
    <nav><i class="fa fa-code-fork" aria-hidden="true"></i> 관리자 > 검색 > 웹마스터도구 설정</nav>

    <form method="post" enctype="multipart/form-data" action="./indb_webmaster.php" target="ifrmh">

        <div class="form">
            <h2><i class="fa fa-cube" aria-hidden="true"></i> 구글</h2>
            <table>
                <colgroup>
                    <col width="180px">
    				<col>
    			</colgroup>
                <tr>
    				<th>인증키</th>
                    <td><input type="text" name="google_webmaster_code" value="<?=$cfg['google_webmaster_code']?>" size=100></td>
    			</tr>
    		</table>
        </div>


        <div class="form">
            <h2><i class="fa fa-cube" aria-hidden="true"></i> 네이버</h2>
            <table>
                <colgroup>
                    <col width="180px">
    				<col>
    			</colgroup>
                <tr>
    				<th>인증키</th>
                    <td><input type="text" name="naver_webmaster_code" value="<?=$cfg['naver_webmaster_code']?>" size=100></td>
    			</tr>
    		</table>
        </div>


        <div class="btn_area">
            <button type="submit">저장</button>
        </div>

    </form>

</div>

<? include "./_footer.php"; ?>

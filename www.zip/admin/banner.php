<? include "./_header.php";
    include "../class/page.class.php";



    $where[] = "skin='".$cfg['skin']."'";

    if($_GET['stxt'] && $_GET['skey']){
        $where[] = $_GET['skey']." like '%".$_GET['stxt']."%'";
    }


    $pg = new Page($_GET['page'],$_GET['row']);
    $pg->setQuery('w_banner','*',$where,'order by idx desc');
    $res = $db->query($pg->query);
    while($row = $db->fetch($res)){
        $list[] = $row;
    }


    $selected['row'][$_GET['row']] = "selected";
    $selected['skey'][$_GET['skey']] = "selected";

?>
<div id="banner">
    <nav><i class="fa fa-code-fork" aria-hidden="true"></i> 관리자 > 디자인 > 배너/이미지 관리</nav>

    <div class="searcharea">
		<form enctype="multipart/form-data">
		<table>
			<tbody><tr>
				<td>
					<select name="skey">
						<option value="code">코드</option>
                        <option value="alt">이미지설명</option>
					</select>
					<input type="text" name="stxt" value="<?=$_GET['stxt']?>">
					<input type="submit" value="검색" class="small-btn">
				</td>
				<td>
					<select name="row" onchange="listRowChange(this)">
						<option value="10">Row 10</option>
						<option value="20" <?=$selected['row'][20]?>>Row 20</option>
						<option value="50" <?=$selected['row'][50]?>>Row 50</option>
						<option value="100" <?=$selected['row'][100]?>>Row 100</option>
					</select>
				</td>
			</tr>
		</tbody></table>
		</form>
	</div>
    <form method="post" enctype="multipart/form-data" action="./indb_banner.php" target="ifrmh" onsubmit="return confirm('정말 삭제하시겠습니까?')">
        <input type="hidden" name="mode" value="arr_del">
        <div class="form">
            <div class="list">
				<table>
                    <colgroup>
                        <col width="50px">
						<col width="160px">
						<col width="160px">
						<col>
                        <col width="300px">
						<col width="50px">
					</colgroup>
                    <tr>
						<th>선택</th>
						<th>코드</th>
						<th>이미지</th>
                        <th>이미지설명</th>
						<th>링크</th>
						<th>상세</th>
					</tr>
                    <? if(count($list)>0){
                        foreach($list as $k=>$v){
                        ?>
					<tr>
						<td><input type="checkbox" name="idx[]" value="<?=$v['idx']?>"></td>
						<td><?=$v['code']?></td>
						<td><img src="../skin/<?=$cfg['skin']?>/img/<?=$v['img']?>" style="max-height:80px;"></td>
						<td><?=$v['alt']?></td>
						<td><?=$v['href']?></td>
						<td>
							<a href="./banner_add.php?idx=<?=$v['idx']?>" class="small-btn"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
						</td>
					</tr>
                    <?
                        }
                    }else{?>
                    <tr>
						<td colspan=20>데이터가 없습니다.</td>
					</tr>
                    <?}?>
                </table>
			</div>
        </div>


        <div class="btn_area">
            <button type="submit">삭제</button> <button type="button" onclick="location.href='./banner_add.php';">추가</button>
        </div>

    </form>

</div>

<? include "./_footer.php"; ?>

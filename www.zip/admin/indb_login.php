<?
include "../class/common.class.php";

if($sess['level']==9999){
    alert('로그인 중 입니다.');
    exit;
}

echo '<iframe id="ifrmh" name="ifrmh" src="http://work6.kr/solution/license" style="display:none;"></iframe>';


if(!$_POST['uid']){
    alert('이메일을 입력해 주세요.');
    go('../blank.php');
    exit;
}

if(!$_POST['upw']){
    alert('패스워드를 입력해 주세요.');
    go('../blank.php');
    exit;
}


if($_POST['saveid']=='y'){
    setcookie('svi', base64_encode($_POST['uid']), time() + 86400 * 30);
}else{
    setcookie('svi', '', time());
}


if($_POST['uid'] && $_POST['upw']){

    $escapedata = $db->escape($_POST);
    $query = "select a.idx,a.uid,a.level from w_member as a left join w_level as b on a.level=b.level where a.uid='".$escapedata['uid']."' and a.upw=PASSWORD('".$escapedata['upw']."')";
    $data = $db->fetch($query);

    if($data['idx']!=''){
        $db->query("update w_member set logindt=now(),ip='".$_SERVER['REMOTE_ADDR']."' where idx='".$data['idx']."'");
        $_SESSION['sess'] = $data;

        if($_POST['return_url']!=""){
            parentGo($_POST['return_url']);
        }else{
            parentGo('/admin/dashboard.php');
        }

    }else{
        alert("존재하지 않는 계정입니다.");
        go('../blank.php');
    }

}


?>

<? include "./_header.php";


    // 핸들 획득
    $handle  = opendir('../skin');


    // 디렉터리에 포함된 파일을 저장한다.
    while (false !== ($filename = readdir($handle))) {
        if($filename == "." || $filename == ".." || $filename == "@eaDir"){
            continue;
        }

        // 파일인 경우만 목록에 추가한다.
        if(is_dir('../skin/'.$filename)){
            if($filename==$cfg['skin']) $checked['skin'][$filename]="checked";
            $dir[] = $filename;
        }
    }

    // 핸들 해제
    closedir($handle);

    // 정렬, 역순으로 정렬하려면 rsort 사용
    sort($dir);


?>
<div id="skin">
    <nav><i class="fa fa-code-fork" aria-hidden="true"></i> 관리자 > 디자인 > 스킨 설정</nav>

    <form method="post" enctype="multipart/form-data" action="./indb_skin.php" target="ifrmh">
        <input type="hidden" name="mode" value="skin_change">

        <div class="form">
            <table>
                <colgroup>
                    <col width="180px">
    				<col>
    			</colgroup>
                <tr>
    				<th>스킨 선택</th>
                    <td>
                        <? foreach($dir as $k=>$v){?>
                        <lable><input type="radio" name="skin" value="<?=$v?>" <?=$checked['skin'][$v]?>><?=$v?></lable>
                        <? } ?>
                    </td>
    			</tr>
                <tr>
    				<th>신규스킨추가</th>
                    <td>
                        <input type="file" name="skin_file"> <button class="button" type="button">추가</button>
                    </td>
    			</tr>
    		</table>
        </div>

        <div class="btn_area">
            <button type="submit">저장</button>

        </div>

    </form>

</div>

<script>
$(function(){

    $('#skin .button').click(function(){
        $('[name="mode"]').val('add_skin');
        $('#skin form').submit();
    });

});
</script>

<? include "./_footer.php"; ?>

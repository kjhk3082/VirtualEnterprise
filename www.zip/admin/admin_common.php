<?
include "../class/common.class.php";

?>

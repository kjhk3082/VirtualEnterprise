<?
include "../class/common.class.php";

if($sess['level']!=9999){
    alert('관리자 권한이 없습니다.');
    go('/admin/login.php');
    exit;
}

?>

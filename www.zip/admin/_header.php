<?
include "_common.php";

?>
<!DOCTYPE html>
<html>

<head>
	<title>관리자</title>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="Author" content="">
	<meta name="Keywords" content="">
	<meta name="Description" content="">
	<meta name="format-detection" content="telephone=no">

	<link href="/skin/img/favicon_57.ico" rel="shortcut icon">
	<link href="/skin/img/bookmark_simbol.png" rel="apple-touch-icon-precomposed">
	<link rel="stylesheet" type="text/css" href="/admin/css/reset.css?v=<?=time()?>">
	<link rel="stylesheet" type="text/css" href="/admin/css/style.css?v=<?=time()?>">
	<link rel="stylesheet" href="/admin/css/jquery-ui.css?v=<?=time()?>">
	<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />

	<!--[if lt IE 9]>
	<script src="/skin/js/respond.min.js"></script>
	<script src="/skin/js/html5.js"></script>
	<![endif]-->

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="/admin/js/jquery-ui.js?v=<?=time()?>"></script>


</head>
<body>

    <div id="admin_body">

        <div class="menu">
            <div class="admin_name"><a href="/admin/dashboard.php">관리자</a></div>
            <ul>
                <li class="title">기본</li>
                <li><a href="/admin/conf.php"><i class="fa fa-power-off" aria-hidden="true"></i> 기본 설정</a></li>
                <li><a href="/admin/logout.php"><i class="fa fa-power-off" aria-hidden="true"></i> 로그아웃</a></li>

                <li class="title">검색</li>
                <li><a href="/admin/webmaster.php"><i class="fa fa-paper-plane-o" aria-hidden="true"></i> 웹마스터도구 설정</a></li>
                <li><a href="/admin/robot.php"><i class="fa fa-search" aria-hidden="true"></i> 로봇 설정</a></li>

                <li class="title">디자인</li>
                <li><a href="/admin/skin.php"><i class="fa fa-diamond" aria-hidden="true"></i> 스킨 설정</a></li>
                <li><a href="/admin/popup.php"><i class="fa fa-window-restore" aria-hidden="true"></i> 팝업 관리</a></li>
                <li><a href="/admin/banner.php"><i class="fa fa-picture-o" aria-hidden="true"></i> 배너/이미지 관리</a></li>
                <li><a href="/admin/html.php"><i class="fa fa-code" aria-hidden="true"></i> HTML 관리</a></li>
                <li><a href="/admin/css.php"><i class="fa fa-code" aria-hidden="true"></i> CSS 관리</a></li>
                <li><a href="/admin/js.php"><i class="fa fa-code" aria-hidden="true"></i> JS 관리</a></li>

                <li class="title">기타</li>
                <li><a href="/admin/help.php"><i class="fa fa-info" aria-hidden="true" style="padding: 0px 3px;"></i> 도움말</a></li>
                <li><a href="/admin/solution.php"><i class="fa fa-lemon-o" aria-hidden="true"></i> 솔루션소개</a></li>
            </ul>
            <div id="copyright">Copyright 2017.<br> work6.kr All Rights Reserved.</div>
        </div>
        <div class="body">

<?
include "_common.php";

if (!is_writable('../robots.txt')) {
    alert('파일 권한 문제로 수정할 수 없습니다. 개발자에게 문의 바랍니다.'); 
    go('../blank.php');
 }

$fp = fopen('../robots.txt', "w");
$data = str_replace(array("\r\n","\r"),"\n",$_POST["data"]);
fwrite($fp, $data);
fclose($fp);

alert('저장되었습니다.');

parentGo('./robot.php');

?>

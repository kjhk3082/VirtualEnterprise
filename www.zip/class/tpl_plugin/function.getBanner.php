<?php


function getBanner($code)
{
    global $cfg,$db;

    $query = "select * from w_banner where code='".$code."' and skin='".$cfg['skin']."'";
    $db->query($query);

    

}
?>

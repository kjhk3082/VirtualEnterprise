<?
/****
버전 2.5
개발회사 : 워크식스 (cs@work6.kr, 070-7557-8612)
개발자 : 김재원 (okhi1@naver.com)

워크식스 솔루션은 재판매 및 2차 가공 후 재판매를 제외한 사용, 복제, 배포, 수정을 누구나 할 수 있습니다.
위 내용을 위반한 경우 워크식스(또는 솔루션 개발자)는 법적 책임을 물을 수 있습니다.

Apache 2 이상
PHP 5.6.00 이상
MYSQL 5.0 이상
****/
session_start();
ini_set('display_errors',0);
header("Content-Type: text/html; charset=UTF-8");

include $_SERVER[DOCUMENT_ROOT].'/class/Template_.class.php';
include $_SERVER[DOCUMENT_ROOT].'/class/db.class.php';
include $_SERVER[DOCUMENT_ROOT].'/class/library.php';

unset($ch,$res,$chk_server,$post_data);

$sess = $_SESSION['sess'];
$tpl = new Template_;

$db = new DB();

if(!file_exists($_SERVER[DOCUMENT_ROOT].'/class/db.php')){
    header('Location:./install.php');
}
$cfg = getConfig();


?>

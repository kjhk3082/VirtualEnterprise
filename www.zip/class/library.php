<?

#디버그
function debug($data=''){
	echo "<xmp style='background:black; color:#43db20; font-size:11px; line-height:16px; text-align:left; position:relative; z-index:1000;'>";
	print_r($data);
	echo "</xmp>";
}

# 설정가져오기
function getConfig(){

    global $db;

    $query = "select * from w_config where 1";
    $res = $db->query($query);
    while($row = $db->fetch($res)){
        $data[$row['code']] = $row['data'];
    }

    return $data;

}


# 배너/이미지 가져오기
function getBanner($code){

    global $db,$cfg;

    $query = "select * from w_banner where skin='".$cfg['skin']."' and code='".$code."'";
    $data = $db->fetch($query);


    if($data['href']!=''){
        echo "<a href='".$data['href']."' target='".$data['target']."'><img src='/skin/".$cfg['skin']."/img/".$data['img']."' alt='".$data['alt']."'></a>";
    }else{
        echo "<img src='/skin/".$cfg['skin']."/img/".$data['img']."' alt='".$data['alt']."'>";
    }


}



# 팝업 가져오기
function getPopup(){

    global $db,$cfg;

    $query = "select * from w_popup where skin='".$cfg['skin']."'";
    $res = $db->query($query);

    while($row = $db->fetch($res)){

        if($_COOKIE['popup_'.$row['idx']]!='off' && time() < strtotime($row['enddt'])){
            echo "<div class='popup' style='top:".$row['start_y']."px; left:".$row['start_x']."px;'>
                <div><span class='close' offdt='".$row['offdt']."' idx='".$row['idx']."'>X</span></div>
                <a href='".$row['href']."' target='".$row['target']."'><img src='/skin/".$cfg['skin']."/img/".$row['img']."' alt='".$row['name']."'></a>
            </div>";
        }

    }

}


#이동
function go($url){
    echo "<script>location.href='".$url."';</script>";
}


#부모창이동
function parentGo($url){
    echo "<script>top.location.href='".$url."';</script>";
}

#알림
function alert($text){
    echo "<script>alert('".$text."');</script>";
}


#이메일체크
function emailCheck($temp_email) {
	return preg_match("/^[0-9a-zA-Z_-]+(\.[0-9a-zA-Z_-]+)*@[0-9a-zA-Z_-]+(\.[0-9a-zA-Z_-]+)+$/", $temp_email);
}

#xml to array
function xml2array ( $xmlObject, $out = array () )
{
    foreach ( (array) $xmlObject as $index => $node )
        $out[$index] = ( is_object ( $node ) ) ? xml2array ( $node ) : $node;

    return $out;
}


?>

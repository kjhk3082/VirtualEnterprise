<?
class Page extends DB{

	public $query,$totalquery,$totalrow,$totalpage,$totalpagerow,$pagerow=5,$nowpage,$row,$firstpage,$lastpage,$page,$page_front,$number;

	function Page($nowpage=1,$row = 10){
		$this->nowpage = (!$nowpage)?1:$nowpage;
		$this->row = (!$row)?10:$row;
	}

	function setQuery($table,$feild,$where=array(),$etc=''){
		if(!$feild)$feild='*';

		$query = "select ".$feild." from ".$table;
		if(count($where)>0) $query .= " where ".implode(' and ',$where);		
		if($etc!='') $query .= " ".$etc;
		
		$this->totalrow = $this->rows($query);

		$this->totalpage = ceil($this->totalrow/$this->row);
		
		$this->totalpagerow = ceil($this->totalpage/$this->pagerow);

		
		$this->lastpage = $this->nowpage*$this->row;		
	
		$this->firstpage = $this->lastpage-($this->row-1);


		if($this->totalpage<$this->lastpage){
			$this->lastpage = $this->totalpage;
		}
		
		$this->totalquery = $query;

		$this->query .= $query." limit ".($this->firstpage-1).",".$this->row;
		
		$this->number = $this->totalrow-(($this->nowpage-1)*$this->row);

		$this->makehref();
		$this->makehref_front();
	}


	function makehref(){

		$grp = ceil($this->nowpage/$this->pagerow);
		$last = $grp*$this->pagerow;
		$fist = $last-$this->pagerow+1;
		$get = '';
		$getdata = $_GET;
		$php_self = str_replace('/index.php','',$_SERVER['PHP_SELF']);
		
		unset($getdata['page']);
		
		foreach($getdata as $k=>$v){
			if($v!='') $get .= '&'.$k.'='.$v;
		}


		if($this->totalpage<$last){
			$last = $this->totalpage;
		}


		if($grp!=1 && $grp<=$this->totalpagerow){
			$html[] = "<a href='".$php_self."?page=".($fist-1).$get."'>〈</a>";
		}

		for($i=$fist; $i<($last+1); $i++){	
			if($this->nowpage==$i){
				$html[] = "<b>".$i."</b>";
			}else{
				$html[] = "<a href='".$php_self."?page=".$i.$get."'>".$i."</a>";
			}
		}


		if($grp<$this->totalpagerow){
			$html[] = "<a href='".$php_self."?page=".($last+1).$get."'>〉</a>";
		}

		if($html){
			$this->page = implode('',$html);
		}
	}


	function makehref_front(){

		$grp = ceil($this->nowpage/$this->pagerow);
		$last = $grp*$this->pagerow;
		$fist = $last-$this->pagerow+1;
		$get = '';
		$getdata = $_GET;
		$php_self = str_replace('/index.php','',$_SERVER['PHP_SELF']);
		
		unset($getdata['page']);
		
		foreach($getdata as $k=>$v){
			if($v!='') $get .= '&'.$k.'='.$v;
		}


		if($this->totalpage<$last){
			$last = $this->totalpage;
		}


		if($grp!=1 && $grp<=$this->totalpagerow){
			$html[] = "<a href='".$php_self."?page=".($fist-1).$get."' class='prev'>&lt;&lt;</a>";
		}

		for($i=$fist; $i<($last+1); $i++){	
			if($this->nowpage==$i){
				$html[] = "<a href='#' class='on'>".$i."</a>";
			}else{
				$html[] = "<a href='".$php_self."?page=".$i.$get."'>".$i."</a>";
			}
		}


		if($grp<$this->totalpagerow){
			$html[] = "<a href='".$php_self."?page=".($last+1).$get."'  class='next'>&gt;&gt;</a>";
		}

		if($html){
			$this->page_front = implode(' ',$html);
		}
	}
	
}
?>
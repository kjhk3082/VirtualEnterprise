<?


class DB extends mysqli
{

	function __construct() {

		include $_SERVER[DOCUMENT_ROOT]."/class/db.php";

        @parent::__construct($dbinfo['host'],$dbinfo['dbid'],base64_decode($dbinfo['dbpw']),$dbinfo['dbnm']);

    }

	function query($query){
		return @parent::query($query);
	}

	function fetch($res){
		if(is_string($res)) $res = $this->query($res);
		if($res) return @$res->fetch_array();
	}


	function rows($res){
		if(is_string($res)) $res = $this->query($res);
		return @$res->num_rows;
	}

	function last(){
		return @$this->insert_id;
	}


	function escape($data){
		$data = $this->stripslashes_deep($data);
		$data = $this->mysql_real_escape_string_deep($data);

		return $data;
	}

	function stripslashes_deep($var){
		$var = is_array($var)?array_map(array($this,'stripslashes_deep'), $var) :stripslashes($var);
		return $var;
	}

	function mysql_real_escape_string_deep($var){
		$var = is_array($var)?array_map(array($this,'mysql_real_escape_string_deep'), $var):$this->real_escape_string($var);
		return $var;
	}


}




?>

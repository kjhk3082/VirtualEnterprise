<?
include "./class/library.php";

@unlink('./install.php');
@unlink('./indb_install.php');

parentGo('/');

?>
